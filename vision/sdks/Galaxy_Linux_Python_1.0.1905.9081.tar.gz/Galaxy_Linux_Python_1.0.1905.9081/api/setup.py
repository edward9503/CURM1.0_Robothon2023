#!/usr/bin/env python
# -*- coding:utf-8 -*-
from __future__ import print_function
from setuptools import setup, find_packages
import sys

setup(
    name='gxipy',
    version='1.0.1905.9051',
    description='',
    license='MIT',
    packages=['gxipy'],
)
