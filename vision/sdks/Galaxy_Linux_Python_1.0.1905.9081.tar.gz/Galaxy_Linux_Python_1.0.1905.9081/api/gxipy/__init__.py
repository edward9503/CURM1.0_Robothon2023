#!/usr/bin/python
# -*- coding:utf-8 -*-
# -*-mode:python ; tab-width:4 -*- ex:set tabstop=4 shiftwidth=4 expandtab: -*-

from gxipy.gxiapi import *
from gxipy.gxidef import *


__all__ = ["gxwrapper", "dxwrapper", "gxiapi", "gxidef"]

__version__ = '1.0.1905.9051'
